create function like_rev(text, text) returns boolean
    language sql
as
$$
select $2 like $1
$$;

alter function like_rev(text, text) owner to postgres;

